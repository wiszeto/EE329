/*
 * ADC.h
 *
 *  Created on: May 24, 2023
 *      Author: Zack's PC
 */

#ifndef INC_ADC_H_
#define INC_ADC_H_

void ADC_Init(void);

#endif /* INC_ADC_H_ */
