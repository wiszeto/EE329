/**
  ******************************************************************************
 * @file     : main.c
 * project   : EE 329 A6
 * details   : UART
 * authors   : Wilson Szeto  
 * 	         : Grace Paladichuk
 * version   : 0.1
 * date      : 4/21/2023
 * compiler  : STM32CubeIDE Version: 1.12.0
 * target    : NUCLEO L4A6ZG

  ******************************************************************************
*/
#include "main.h"
#include “uart.h”

void SystemClock_Config(void);
void LPUART_init();
void LPUART_Print(const char *message);
void LPUART_Print_Char(char ch);
void LPUART_ESC_Print(const char *message);

const uint32_t max_rows=20;
const uint32_t max_cols=80;
uint32_t rows=10;
uint32_t cols=40;

void delay_us(const uint32_t time_us) {
	// set the counts for the specified delay
	SysTick->LOAD = (uint32_t)((time_us * (SystemCoreClock / 1000000)) - 1);
	SysTick->VAL = 0;                                  	 // clear timer count
	SysTick->CTRL &= ~(SysTick_CTRL_COUNTFLAG_Msk);    	 // clear count flag
	while (!(SysTick->CTRL & SysTick_CTRL_COUNTFLAG_Msk));     // wait for flag
}


int main(void) {
	HAL_Init();
	SystemClock_Config();
	LPUART_init();

	//For Splash Screen
	for(int i=0; i<2; i++){
	LPUART_ESC_Print("\033[10;32H");   //set cursor to print title in center
	LPUART_Print("X Marks the Spot");  //print title

	LPUART_ESC_Print("\033[11;22H");   //shift cursor down and left to start image
    //Line 1
	for(int i=0; i<16; i++){           //print wire
			LPUART_Print("-");
		}
	for(int i=0;i<4; i++){             //print resistor
	LPUART_Print("/");
	LPUART_Print("\\");
	}
	for(int i=0; i<16; i++){         //print wire
		LPUART_Print("-");			
	}
	LPUART_ESC_Print("\033[B");      //shift cursor 1 down
	LPUART_ESC_Print("\033[40D");    //shift to the left
	//Line 2-4
	for(int i=0; i<3; i++){          
		LPUART_Print("|");            //print space
		for(int i=0; i<38; i++){     //print space
			LPUART_Print(" ");      
		}
		LPUART_Print("|");              //print wire
		LPUART_ESC_Print("\033[B");      //shift cursor 1 down
		LPUART_ESC_Print("\033[40D");    //shift to the left
	}
	//line 5
	LPUART_Print("-");          //print neg side of voltage source
	for(int i=0; i<37; i++){  //spaces
		LPUART_Print(" ");
	}
	LPUART_Print("---");           //print top of capacitor
	LPUART_ESC_Print("\033[B");      //shift cursor 1 down
	LPUART_ESC_Print("\033[42D"); //shift to the left
	//line 6
	LPUART_Print("---");           //print pos side of voltage source
	for(int i=0; i<36; i++){    //print space
			LPUART_Print(" ");
    }
	LPUART_Print("---");             //print bottom of capacitor
	LPUART_ESC_Print("\033[B");      //shift cursor 1 down
    LPUART_ESC_Print("\033[41D"); //shift to the left
    //Line 7-8
	for(int i=0; i<2; i++){
		LPUART_Print("|");          //print wire
		for(int i=0; i<38; i++){   //print spaces
			LPUART_Print(" ");
		}
		LPUART_Print("|");               //print wire
		LPUART_ESC_Print("\033[B");      //shift cursor 1 down
		LPUART_ESC_Print("\033[40D"); //shift to the left
	}
	//line 9
	for(int i=0; i<18; i++){           //print wire
				LPUART_Print("-");   
			}
		LPUART_Print("|>|");           //print diodes
		for(int i=0; i<19; i++){
			LPUART_Print("-");         //print wire
		}

	delay_us(20000000);   //wait 2 sec
	LPUART_ESC_Print("\033[2J"); //clear screen
	delay_us(5000000);   //wait 500 msec
	}

	LPUART_ESC_Print("\033[2J"); //clear screen
	LPUART_ESC_Print("\033[10;40H");   //set cursor to the center of the screen
	LPUART_ESC_Print("\033[25l");      //hide cursor
	LPUART_Print("X");            //print icon

	while (1) {
	}

}


void LPUART1_IRQHandler(void){
	if (LPUART1->ISR & USART_ISR_RXNE) {
		char charRecv = LPUART1->RDR;  // read the received character
		LPUART_ESC_Print("\033[D");    //shift cursor 1 to the left
		switch (charRecv) {
		case 'd': //move right
			if(cols==max_cols){           //check if cursor is at right boundary
			LPUART_ESC_Print("\033[2J");  //clear line from left of cursor
			LPUART_ESC_Print("\033[80D"); //shift to the far left side of screen
			LPUART_Print("X");            //print icon
			cols=0;                       //set columns to far left position
			} else{
			LPUART_ESC_Print("\033[1K");  //clear line from left of cursor
			LPUART_ESC_Print("\033[C");   //shift cursor 1 to the right
			LPUART_Print("X"); 			  //print icon
			cols++;                       //increment column count
			}
			break;
		case 'a': //move left
			if(cols==0){                  //check if cursor is at left boundary
			LPUART_ESC_Print("\033[0K");  //clear line from right of cursor
			LPUART_ESC_Print("\033[80C");   //shift to the far right of the screen
			LPUART_Print("X");				//print icon
			cols=max_cols;                 //set columns to the far right position
			} else{
			LPUART_ESC_Print("\033[D");    //shift cursor 1 to the left
			LPUART_Print("X");				//print icon
			LPUART_ESC_Print("\033[0K");  //clear line from right of cursor
			cols--;                       //decrement column count
			}
			break;
		case 's':   //move down
			if(rows==0){                   //check if cursor is at bottom boundary
			LPUART_ESC_Print("\033[1J");   //clear screen from cursor up
			LPUART_ESC_Print("\033[21A");  //shift to top of screen
			LPUART_Print("X");				//print icon
			rows=max_rows;                  //set rows to top value
			} else {
			LPUART_ESC_Print("\033[1J");    //clear screen from cursor up
			LPUART_ESC_Print("\033[B");      //shift cursor 1 down
			LPUART_Print("X");				//print icon
			rows--;	                        //decrement row count
			}
			break;
		case 'w':   //move up
			if(rows==max_rows){            //check if cursor is at top boundary
			LPUART_ESC_Print("\033[J");    //clear screen from cursor down
			LPUART_ESC_Print("\033[21B"); //shift to bottom of screen
			LPUART_Print("X");				//print icon
			rows=0;                       //set rows to bottom value
			} else{
			LPUART_ESC_Print("\033[A");     //shift cursor 1 up
			LPUART_Print("X");				//print icon
			LPUART_ESC_Print("\033[J");     //clear screen from cursor down
			rows++;                         //increment row count
			}
			break;
		default:
			break;
		}
		}
}


void SystemClock_Config(void) {
	RCC_OscInitTypeDef RCC_OscInitStruct = { 0 };
	RCC_ClkInitTypeDef RCC_ClkInitStruct = { 0 };

	/** Configure the main internal regulator output voltage
	 */
	if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1)
			!= HAL_OK) {
		Error_Handler();
	}
	/** Initializes the RCC Oscillators according to the specified parameters
	 * in the RCC_OscInitTypeDef structure.
	 */
	RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_MSI;
	RCC_OscInitStruct.MSIState = RCC_MSI_ON;
	RCC_OscInitStruct.MSICalibrationValue = 0;
	RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_6;
	RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
	if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) {
		Error_Handler();
	}

	/** Initializes the CPU, AHB and APB buses clocks
	 */
	RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
			| RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
	RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_MSI;
	RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
	RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
	RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

	if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK) {
		Error_Handler();
	}
}

void Error_Handler(void) {
	__disable_irq();
	while (1) {
	}

}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{

}
#endif /* USE_FULL_ASSERT */