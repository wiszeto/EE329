# import serial

# # Open the serial port.
# ser = serial.Serial('COM3', 115200)

# try:
#     while True:
#         if ser.in_waiting > 0:
#             byte = ser.read()
#             print(byte)


# except KeyboardInterrupt:
#     print("Ending")


import serial

# Open the serial port.
ser = serial.Serial('COM3', 9600)

try:
    # The bytes to send.
    bytes_to_send = b"Hellosdfg\n"
    data = "wilson" + '\n'
    # Send it over the UART.
    ser.write(data.encode())

except Exception as e:
    # If there's an error, print it out.
    print("Error: ", str(e))

finally:
    # Close the serial port when you're done with it.
    ser.close()

