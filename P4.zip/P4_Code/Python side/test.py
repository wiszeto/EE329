import json
import os

def uart_read_thread():
    # load existing data if the file exists
    if os.path.exists('students.json'):
        with open('students.json', 'r') as f:
            data = json.load(f)
    else:
        data = {'students': []}

    for i in range(0, 2):
            line = "Wilson,12546"
            print(line)

            # split line into name and id
            name, id = map(str.strip, line.split(','))

            # add new student to data
            data['students'].append({
                'id': id,
                'name': name,
            })

            # save data back to file
            with open('students.json', 'w') as f:
                json.dump(data, f)

uart_read_thread()