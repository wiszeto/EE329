# Import required modules
import discord
from discord import ui, app_commands
from discord.ext import commands
import threading
import asyncio
import serial
from datetime import datetime
from datetime import date
import pandas as pd

#specify serial communication port and baud rate
ser = serial.Serial('COM3', 9600)

class ComsCog(commands.Cog):
    #startup code
    def __init__(self, bot):
        self.bot = bot
        self.thread = threading.Thread(
            target=self.uart_read_thread, daemon=True)
        self.queue = asyncio.Queue()
        self.thread.start()
        self.bot.loop.create_task(self.process_queue())

    #attribute declearations 
    enroll_count = 0
    enroll_count1 = 0
    start=0
    end=0
    tardy=0
    
    @app_commands.command(name="clear", description="resets database for a new class")
    async def clear(self, ctx: commands.Context, name: str):
        #clears enrolled students and associated ids
        self.enroll_count = 0
        self.enroll_count1 = 0
        data = {'Name': [None]*100,
                'id': [None]*100}

        #clear excel files
        df = pd.DataFrame(data)
        df1 = pd.DataFrame()
        df.to_excel('output.xlsx', index=False)
        df1.to_excel('output2.xlsx', index=False)

        #discord notification message
        await ctx.response.send_message('Clear success!', ephemeral=True)

    @app_commands.command(name="enroll", description="enroll for a class")
    async def enroll(self, ctx: commands.Context, name: str):
        #send header
        byte = b'\xEF\x02' 
        ser.write(byte)

        #log student in excel sheet
        new_df = pd.read_excel('output.xlsx')
        new_df.loc[self.enroll_count1] = [name, self.enroll_count1]
        new_df.to_excel('output.xlsx', index=False)
        self.enroll_count1 += 1
        data = name.ljust(16, ' ') + '\n'

        #sends name to uart to indicate who is enrolling
        ser.write(data.encode())

        #discord notification message
        await ctx.response.send_message('Enrollment successful, please place thumb on sensor.', ephemeral=True)

    @app_commands.command(name="attendance", description="start a class with a specified time")
    async def attendance(self, ctx: commands.Context, date1: str = "a", start: int = 1000, 
                         end: int = 1010, tardy: int = 1030):
        #send header
        byte = b'\xEF\x03'
        ser.write(byte)

        #update variables for fingerprint checking
        self.start = start  
        self.end = end  
        self.tardy = tardy
        if date1 == "a":
            current_date = str(date.today())
        df = pd.read_excel('output2.xlsx')

        #prepare excel file for new day
        df[current_date] = [None] * len(df)  # clear excel file from previous data
        df.to_excel('output2.xlsx', index=False)  #update excel file
        df = pd.read_excel('output2.xlsx')
        # Set the values of the second row to leave blank
        df.loc[1] = "leave blank"
        df.to_excel('output2.xlsx', index=False) #update excel file

        #discord notification message
        await ctx.response.send_message('Attendance successful', ephemeral=True)

    @app_commands.command(name="export", description="Export the excel file")
    async def export(self, ctx: commands.Context):
        await ctx.response.send_message('Export successful', ephemeral=True)
        #sends the excel file
        await ctx.followup.send(file=discord.File('output2.xlsx'))

        
    def uart_read_thread(self):
        while True:
            # Check if any data is available for reading
            if ser.in_waiting > 0:
                line = ser.readline().decode('utf-8')
                index = line.find("Send")

                # Check if a fingerprint event is detected (by looking for "Send" in data)
                if index != -1:
                    index += len("Send")

                    # Load the data from 'output.xlsx'
                    df = pd.read_excel('output.xlsx')

                    # Find the name corresponding to the id
                    name = df.loc[df['id'] == int(line[index:]), 'Name'].values[0]

                    # Pad start and end times with zeros if less than 4 digits
                    start_time_str = str(self.start).zfill(4)
                    end_time_str = str(self.tardy).zfill(4)

                    # Convert the start, end, and current time to datetime.time objects
                    start_time = datetime.strptime(start_time_str, "%H%M").time()
                    end_time = datetime.strptime(end_time_str, "%H%M").time()
                    current_time = datetime.now().time()

                    # Check if the current time is within the start and end times
                    status = " on time at " if start_time <= current_time <= end_time else " tardy "

                    # Format message for the Excel sheet
                    x = name + " is" + status + str(datetime.now())

                    # Load 'output2.xlsx' and write the message to the last column
                    df2 = pd.read_excel('output2.xlsx')
                    df2[df2.columns[-1]] = df2[df2.columns[-1]].astype(str)
                    last_non_null_index = df2[df2.columns[-1]].last_valid_index()

                    # Add data at the correct index in the dataframe and save to the excel file
                    if last_non_null_index is None:
                        df2.at[0, df2.columns[-1]] = x
                    else:
                        df2.at[last_non_null_index+1, df2.columns[-1]] = x
                    df2.to_excel('output2.xlsx', index=False)

                    # Send the name to a Discord server
                    asyncio.run_coroutine_threadsafe(
                    self.queue.put(name), self.bot.loop)
                else:
                    print("data not valid")


    async def process_queue(self):
        #this function logs the fingerprint on discord
        while True:
            line = await self.queue.get()
            guild = self.bot.get_guild(1108611624706777178)
            channel = discord.utils.get(
                guild.text_channels, id=1108611625214283796)
            await channel.send(f"Fingerprint used on {datetime.now()} by {line}")


async def setup(bot):  # set async function
    await bot.add_cog(ComsCog(bot))  # Use await
