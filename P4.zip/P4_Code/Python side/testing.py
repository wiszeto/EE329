import datetime

# Convert integer times to string
start_time_int = 1030  # 10:30am
end_time_int = 1301  # 1:01pm

start_time_str = str(start_time_int)
end_time_str = str(end_time_int)

# If the times are less than 4 digits, pad them with zeros
if len(start_time_str) < 4:
    start_time_str = start_time_str.zfill(4)
if len(end_time_str) < 4:
    end_time_str = end_time_str.zfill(4)

# Convert string times to datetime.time objects
start_time = datetime.datetime.strptime(start_time_str, "%H%M").time()
end_time = datetime.datetime.strptime(end_time_str, "%H%M").time()

# Get the current time
current_time = datetime.datetime.now().time()

# Determine if the current time is between start and end times
if start_time < end_time:
    if start_time <= current_time <= end_time:
        print("The current time is between", start_time_str, "and", end_time_str)
    else:
        print("The current time is NOT between", start_time_str, "and", end_time_str)
else:  # crosses midnight
    if start_time <= current_time or current_time <= end_time:
        print("The current time is between", start_time_str, "and", end_time_str)
    else:
        print("The current time is NOT between", start_time_str, "and", end_time_str)
