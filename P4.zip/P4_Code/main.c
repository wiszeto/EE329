/*
 ******************************************************************************
 * file      : main.c
 * project   : EE 329 S'23 P4
 * details   : AttendIO
 * authors   : 	Donna Nikjou (student) - dnikjou@calpoly.edu
 * 				James Savella (student) - savella@calpoly.edu
 * 				Wilson Szeto (student) - wiszeto@calpoly.edu
 * version   : 0.1
 * date      : May 20, 2023
 * compiler  : STM32CubeIDE Version: 1.10.1 (2022)
 * target    : NUCLEO-L4A6ZG
 * 			   Rasberry PI4
 *  *****************************************************************************
 *  Used Pins
 * LCD:
 * PE9  - RS
 * PE10 - RW
 * PE11 - E
 * PE12 - D4
 * PE13 - D5
 * PE14 - D6
 * PE15 - D7
 * Finger print scanner:
 * PA2 - USART TX
 * PA3 - USART RX
 */

#include "main.h"
#include "uart.h"
#include "lcd.h"
#include "delay.h"
#include "fingerprint.h"
#include "FP_process.h"

void SystemClock_Config(void);
void FingerprintErrorHandler(void);
void LPUART_FPID();


#define BUFFER_SIZE 256 //sets buffer size

//For USART2 Acknowledge package
uint8_t errorbuffer[ERROR_BUFFER_SIZE];
static int index0 = 0;
uint8_t ConfirmationCode = 0;
uint32_t currentPacketSize = 0;

//for LPUART Functionality
int index = 0;
uint8_t discordbuffer[BUFFER_SIZE]; //buffer to load discord commands into

//flag initialization
int flag = 0;		//for LPUART handling
int EN_Flag = 0;	//flag for enroll process
int FPIDrdy = 0;	//to send fingerprint ID
int AT_Flag = 0;	//flag for attendance
int EX_Flag = 0;	//flag for exporting data

int main(void) {

	HAL_Init();
	SystemClock_Config();
	LPUART_init();
	LCD_init();
	command(0x0C);

	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOCEN;  // GPIOC clock init
	GPIOC->MODER &= ~(GPIO_MODER_MODE13); // button init
	GPIOC->PUPDR &= ~(GPIO_PUPDR_PUPD13_1);
	GPIOC->PUPDR |= (GPIO_PUPDR_PUPD13_1);
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOBEN;  // GPIOB clock init
	GPIOB->MODER &= ~(GPIO_MODER_MODE7);  // LD2 clear
	GPIOB->MODER |= (GPIO_MODER_MODE7_0); // LD2 output mode

	delay_us(100);
	USART_init();
	delay_us(10000);

	//Fingerprint initialization
	FP_check();	//to check if FP scanner is transmitting properly

	//Empties entire database
	empty(); 		//empties entire database of FP
	MEM_GLOBAL = 0; //resets fingerprint ID

	while (1) {
		if (EN_Flag) {		//enrolls one finger at a time
			FP_enroll();	//enroll process
			EN_Flag = 0;	//resets enroll flag
		}

		while (AT_Flag) { //keep asking for user inputs until time is reached change to while so i can debug
			FP_search();	//fingerprint find process
		}

		if (EX_Flag) {
			uint32_t exportIndex = 0; //sets export index to 0 ready for transmission
			while (exportIndex < MEM_GLOBAL) { //sends data from lowest byte to highest byte
				LPUART_FPID(); //transmits ID to LPUART
				for (int z = 0; z < 16; z++) {	//sends back user name to discord
					while (!(LPUART1->ISR & USART_ISR_TXE))	//waits for buffer to be ready
						;
					LPUART1->TDR = USER_INPUT_NAME[exportIndex][z];
				}
				exportIndex++;	//increments array
				while (!(LPUART1->ISR & USART_ISR_TXE))	//waits for buffer to be ready
					;
				LPUART1->TDR = '\n';
			}
			EX_Flag = 0;	//resets export flag
		}
	}
}

//Interprets instructions sent from discord
void LPUART1_IRQHandler(void) {
	if (LPUART1->ISR & USART_ISR_RXNE) { // check if there is new data in the UART receiver
		uint8_t charRecv = LPUART1->RDR;      // read the received character
		discordbuffer[index] = charRecv; //loads received character into buffer received buffer
		index++;                             //index must be global variable

		if (index == 2) {
			if (discordbuffer[0] == 0xEF && discordbuffer[1] == 0x02) { //wilson send 0xEF02 to indicate beginning of enrollment
			//for each username (16 characters long max for LCD) load it into this variable -> USER_INPUT_NAME[MAX_FP][16];
				EN_Flag = 1;	//sets enroll flag
				AT_Flag = 0;	//resets attends flag
				index = 0;	//resets index location for next acknowledge packets

			}
			if (discordbuffer[0] == 0xEF && discordbuffer[1] == 0x03) { //wilson send 0xEF03 to indicate beginning of attendance?
				EN_Flag = 0;	//resets enroll flag
				AT_Flag = 1;	//sets attends flag
				index = 0;	//resets index location for next acknowledge packets
			}
			if (discordbuffer[0] == 0xEF && discordbuffer[1] == 0x04) { //wilson send 0xEF04 to indicate beginning of attendance?
				EN_Flag = 0;	//resets enroll flag
				AT_Flag = 0;	//resets attends flag
				EX_Flag = 1;	//sets export flag
				index = 0;	//resets index location for next acknowledge packets
			}

		}
		if (charRecv == '\n') { //replace python null terminator with C null terminator
			flag = 1;	//resets flag
			index--;	//checks last instantiation of buffer
			discordbuffer[index] = '\0'; //place user name string into buffer to be written to LCD
			for (int i = 0; i < 16; i++) {
				USER_INPUT_NAME[MEM_GLOBAL][i] = discordbuffer[i];
			}
			index = 0;	//resets index location for next acknowledge packets
		}
	}
}

//To export Fingerprint ID to Raspberry PI4
void LPUART_FPID() {		//send fingerprint ID to discord for processing
	if (FPIDrdy == 1) {
		char FP_ID_string[16]; // 15 digits + null character
		itoa(FP_ID, FP_ID_string); // Convert the uint16_t to a string

		LPUART_Print("Send");	  //header instruction
		LPUART1->TDR = FP_ID_string; // Send the FP_ID as a string
		LPUART_Print("\n");
		FPIDrdy = 0;	//resets flag
	}
}

void USART2_IRQHandler(void) { //[0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27]
	if (USART2->ISR & USART_ISR_RXNE) { // check if there is new data in the UART receiver
		uint8_t charRecv = USART2->RDR;    // read the received character
		errorbuffer[index0] = charRecv; //loads buffer
		index0++;                  //increments index
		if (index0 >= ACK_LENGTH) {
			ConfirmationCode = errorbuffer[9]; //must be global variable to have accessibility
			index0 = 0;
		}
	}
}

void SystemClock_Config(void) {
	RCC_OscInitTypeDef RCC_OscInitStruct = { 0 };
	RCC_ClkInitTypeDef RCC_ClkInitStruct = { 0 };

	if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1)
			!= HAL_OK) {
		Error_Handler();
	}

	RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_MSI;
	RCC_OscInitStruct.MSIState = RCC_MSI_ON;
	RCC_OscInitStruct.MSICalibrationValue = 0;
	RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_6;
	RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
	if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) {
		Error_Handler();
	}

	RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
			| RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
	RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_MSI;
	RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
	RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
	RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

	if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK) {
		Error_Handler();
	}
}

void Error_Handler(void) {

	__disable_irq();
	while (1) {
	}

}

#ifdef  USE_FULL_ASSERT

void assert_failed(uint8_t *file, uint32_t line)
{

}
#endif
