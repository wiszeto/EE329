/*
 * FP_process.c
 *
 *  Created on: Jun 5, 2023
 *      Author: james
 */

#include "main.h"
#include "FP_process.h"
#include "fingerprint.h"
#include "delay.h"
#include "lcd.h"
#include "uart.h"

//global variables
uint8_t MEM_GLOBAL;	//FP ID# LOCATION IN FLASH MEMORY
uint16_t FP_ID = 1234; //FOUND FP ID# LOCATION IN FLASH MEMORY
char USER_INPUT_NAME[MAX_FP][16]; //MAX_FP = max # of users; username 16 char max

//checks if FP is connected and communicating properly
void FP_check(void) {
	lcd_set_cursor_position(0, 0);	//displays message on LCD for user
	str_write("Booting Fngrprnt");
	delay_us(100000);
	lcd_set_cursor_position(1, 0);
	str_write("Scanner         ");
	delay_us(1000000);		//1 second delay to read the message
	handshake();	//command to check if FP is connected
	while (ConfirmationCode != 0x00) {
		handshake();	//keeps sending command to see if module is connected
		lcd_set_cursor_position(0, 0);	//displays message on LCD for user
		str_write("FP Scanner not  ");
		lcd_set_cursor_position(1, 0);
		str_write("found reconnect ");
	}
	//sets other parameters: 2nd argument changes settings
	SetSysPara(4, 6);	//baud rate: 6* 9600 = 57600
	SetSysPara(5, 1);   //security level: 1 - 5 lowest to highest
	SetSysPara(6, 3);	//package length: 0 - 3 lowest to highest
	lcd_set_cursor_position(0, 0);	//displays message on LCD for user
	str_write("FP Scanner      ");
	lcd_set_cursor_position(1, 0);
	str_write("Found           ");
	delay_us(1000000); 		//1 second delay to read the message
	lcd_set_cursor_position(0, 0);
	str_write("                ");
	lcd_set_cursor_position(1, 0);
	str_write("                ");
}

void FP_enroll(void) {
	FP_enroll_start: genImg();	//to get ready to take an input

	for (int buff_local = 1; buff_local <= 2; buff_local++) {
		while (ConfirmationCode == 0x02) {	//No finger detected get finger
			if (buff_local == 1) {
				lcd_set_cursor_position(0, 0);
				str_write("Place finger    ");
				lcd_set_cursor_position(1, 0);
				str_write("                ");
			} else if (buff_local == 2) {
				lcd_set_cursor_position(0, 0);
				str_write("Place finger ");
				lcd_set_cursor_position(1, 0);
				str_write("again         ");
			}
			genImg();	//checks fingerprint
		}
		Img2Tz(buff_local);	//stores in charbuffer

		while (ConfirmationCode == 0x00) { //to wait til user removes finger
			lcd_set_cursor_position(0, 0);
			str_write("Got Finger!     ");
			lcd_set_cursor_position(1, 0);
			str_write("Remove Finger   ");
			genImg(); //checks fingerprint
		}

	}
	regMode(); //generates FP template to store to memory checks if they match as well

	if (ConfirmationCode == 0x00) { //Fingerprint matches!
		lcd_set_cursor_position(0, 0);
		str_write("FP Match Welcome");
		store(1, MEM_GLOBAL); //stores ID to memory, updates ID for each user enrolled
		lcd_set_cursor_position(1, 0);
		for (int i = 0; i < 16; i++) {	//prints user's name onto LCD
			write(USER_INPUT_NAME[MEM_GLOBAL][i]);
		}
		MEM_GLOBAL++;	//updates global array

	} else {
		lcd_set_cursor_position(0, 0);
		str_write("FP mismatch :(  ");
		lcd_set_cursor_position(1, 0);
		str_write("Redo Input      ");

		while (1) {	//To redo input entirely
			genImg();	//checks fingerprint
			if (ConfirmationCode == 0x00)
				goto FP_enroll_start;
			//go back to start
		}
	}
}

//converts integer to str for transmission back to discord
void itoa(uint16_t num, char *str) {
	int i = 0;
	while (num != 0) {
		str[i++] = '0' + (num % 10);
		num /= 10;
	}
	str[i] = '\0';

	// Reverse the string
	for (int j = 0, k = i - 1; j < k; j++, k--) {
		char temp = str[j];
		str[j] = str[k];
		str[k] = temp;
	}
}

//Searches through data base by asking for user input.
void FP_search(void) {
	lcd_set_cursor_position(0, 0);
	str_write("Place Finger    ");
	lcd_set_cursor_position(1, 0);
	str_write("to find it      ");
	genImg();

	while (1) {	//No finger detected get finger
		genImg();	//checks fingerprint
		if (ConfirmationCode == 0x00)
			break;
		//for error handling
		else if ((ConfirmationCode == 0x01) | (ConfirmationCode == 0x03)) {
			lcd_set_cursor_position(0, 0);
			str_write("Place fngr again");
			lcd_set_cursor_position(1, 0);
			str_write("Error clean fngr");
		}
	}
	Img2Tz(1);	//stores in buffer 1

	lcd_set_cursor_position(0, 0);
	str_write("Searching       ");
	lcd_set_cursor_position(1, 0);
	str_write("Database        ");
	search(1, 0, MAX_FP);	//searches through entire database
	if (ConfirmationCode == 0x00) {	//successfully found ID
		FP_ID = errorbuffer[10] + errorbuffer[11]; //gets pageID = location of FP stored in FLASH
		LPUART_Print("Send");	  //header instruction for exporting to excel
		delay_us(10000);
		LPUART1->TDR = errorbuffer[10];	//sends upper byte of pageID
		delay_us(10000);
		LPUART1->TDR = errorbuffer[11]; //sends lower byte of pageID
		delay_us(10000);
		LPUART_Print_Char('\n');
		lcd_set_cursor_position(0, 0);
		str_write("Welcome Back!   ");
		lcd_set_cursor_position(1, 0);

		//prints username onto LCD
		for (int i = 0; i < 16; i++) {
			write(USER_INPUT_NAME[FP_ID][i]); //NEED TO VERIFY IF IT WORKS
		}

	} else if (ConfirmationCode == 0x01) {	//error during transmission
		lcd_set_cursor_position(0, 0);
		str_write("Error During    ");
		lcd_set_cursor_position(1, 0);
		str_write("Transmission    ");
	} else {	//FP not enrolled
		lcd_set_cursor_position(0, 0);
		str_write("FP Not Found    ");
		lcd_set_cursor_position(1, 0);
		str_write("Please Enroll   ");
	}
}
